package com.edos.privatetenders.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.edos.privatetenders.entity.ProductInOrder;

public interface ProductInOrderRepository extends JpaRepository<ProductInOrder, Long> {

}
