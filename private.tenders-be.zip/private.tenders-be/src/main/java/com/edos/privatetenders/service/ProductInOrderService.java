package com.edos.privatetenders.service;

import com.edos.privatetenders.entity.ProductInOrder;
import com.edos.privatetenders.entity.User;

public interface ProductInOrderService {
    void update(String itemId, Integer quantity, User user);
    ProductInOrder findOne(String itemId, User user);
}
