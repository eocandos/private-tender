package com.edos.privatetenders;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrivateTendersApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrivateTendersApplication.class, args);
	}

}
