package com.edos.privatetenders.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.edos.privatetenders.entity.Cart;

public interface CartRepository extends JpaRepository<Cart, Integer> {
}
