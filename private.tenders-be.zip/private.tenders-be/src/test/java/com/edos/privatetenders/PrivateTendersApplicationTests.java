package com.edos.privatetenders;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrivateTendersApplicationTests {

	@Test
	void contextLoads() {
	}

}
